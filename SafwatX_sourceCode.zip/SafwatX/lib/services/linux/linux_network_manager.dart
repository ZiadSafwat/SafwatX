import 'dart:convert';
import 'dart:io';
import 'dart:async';
import '../services.dart';


class LinuxNetworkManager implements NetworkManager {
  @override
  Future<String?> getDefaultInterface() async {
    try {
      final result = await Process.run('ip', ['route']);
      final lines = result.stdout.toString().split('\n');
      for (var line in lines) {
        if (line.startsWith('default')) {
          final parts = line.split(' ');
          final idx = parts.indexOf('dev');
          if (idx != -1 && idx + 1 < parts.length) {
            return parts[idx + 1];
          }
        }
      }
    } catch (e) {
      print("Error getting default interface: $e");
    }
    return null;
  }

  @override
  Future<String?> getGatewayIP() async {
    try {
      final result = await Process.run('ip', ['route']);
      final lines = result.stdout.toString().split('\n');
      for (var line in lines) {
        if (line.startsWith('default')) {
          final parts = line.split(' ');
          return parts.length > 2 ? parts[2] : null;
        }
      }
    } catch (e) {
      print("Error getting gateway IP: $e");
    }
    return null;
  }

  @override
  Future<String?> getMyIP(String interface) async {
    try {
      final result = await Process.run('ip', ['addr', 'show', interface]);
      final match = RegExp(r'inet (\d+\.\d+\.\d+\.\d+)/')
          .firstMatch(result.stdout);
      return match?.group(1);
    } catch (e) {
      print("Error getting IP: $e");
      return null;
    }
  }

  @override
  Future<String?> getMyMAC(String interface) async {
    try {
      final result =
      await Process.run('cat', ['/sys/class/net/$interface/address']);
      return result.stdout.toString().trim();
    } catch (e) {
      print("Error getting MAC: $e");
      return null;
    }
  }

  @override
  Future<String> getHostname(String ip) async {
    try {
      final result = await Process.run('dig', ['+short', '-x', ip]);
      final name = result.stdout.toString().trim();
      return name.isEmpty ? 'Unknown' : name;
    } catch (e) {
      print("Error getting hostname: $e");
      return 'Unknown';
    }
  }

  @override
  Future<String?> getMAC(String ip) async {
    try {
      final result = await Process.run('arp-scan', ['--localnet']);
      for (var line in result.stdout.toString().split('\n')) {
        final parts = line.trim().split(RegExp(r'\s+'));
        if (parts.length >= 2 && parts[0].trim() == ip) {
          return parts[1].trim();
        }
      }
    } catch (e) {
      print("Error getting MAC from IP: $e");
    }
    return null;
  }

  @override
  Future<bool> isDeviceBlocked(String ip, String? mac) async {
    try {
      final ipt = await Process.run('iptables', ['-L', '-v', '-n']);
      final ebt = await Process.run('ebtables', ['-L']);
      return ipt.stdout.toString().contains(ip) ||
          (mac != null && ebt.stdout.toString().contains(mac));
    } catch (e) {
      print("Error checking block status: $e");
      return false;
    }
  }

  @override
  Future<List<Map<String, dynamic>>> scanNetwork() async {
    final iface = await getDefaultInterface();
    if (iface == null) return [];

    final result = await Process.run(
      'arp-scan',
      ['--interface=$iface', '--localnet'],
    );
    final myIp = await getMyIP(iface);
    final myMac = await getMyMAC(iface);
    final myHost = await getHostname(myIp ?? '');

    final devices = <Map<String, dynamic>>[];
    final lines = result.stdout.toString().split('\n');

    final futures = lines.map((line) async {
      final parts = line.split('\t');
      if (parts.length >= 2) {
        final ip = parts[0].trim();
        final mac = parts[1].trim();
        if (ip == myIp) return null;
        final host = await getHostname(ip);
        final blocked = await isDeviceBlocked(ip, mac);
        return {'ip': ip, 'mac': mac, 'name': host, 'blocked': blocked};
      }
      return null;
    }).toList();

    devices.addAll((await Future.wait(futures)).whereType<Map<String, dynamic>>());

    if (myIp != null && myMac != null) {
      devices.add({'ip': myIp, 'mac': myMac, 'name': myHost+"(your Device)", 'blocked': false});
    }

    return devices;
  }

  @override
  Future<Map<String, dynamic>> blockDevice(String ip) async {
    final iface = await getDefaultInterface();
    final gw = await getGatewayIP();
    if (iface == null || gw == null) {
      return {'error': 'Interface or gateway not found'};
    }
    final myIp = await getMyIP(iface);
    final myMac = await getMyMAC(iface);
    if (ip == myIp) return {'error': 'Cannot block yourself'};
    final mac = await getMAC(ip);
    if (mac == null || mac == myMac) {
      return {'error': 'MAC not found or is your own'};
    }
    try {
      await Process.run('pkill', ['-f', 'arpspoof.*-i $iface -t $ip']);
      await Process.start('arpspoof', ['-i', iface, '-t', ip, gw]);
      await Process.run('ebtables', ['-A', 'FORWARD', '-s', mac, '-j', 'DROP']);
      await Process.run('iptables', ['-A', 'FORWARD', '-s', ip, '-j', 'DROP']);
      return {'status': 'blocked', 'ip': ip, 'mac': mac};
    } catch (e) {
      return {'error': e.toString()};
    }
  }

  @override
  Future<Map<String, dynamic>> unblockDevice(String ip) async {
    final iface = await getDefaultInterface();
    if (iface == null) return {'error': 'Interface not found'};
    final mac = await getMAC(ip);
    if (mac == null) return {'error': 'MAC not found'};
    try {
      await Process.run('pkill', ['-f', 'arpspoof.*-i $iface -t $ip']);
      await Process.run('ebtables', ['-D', 'FORWARD', '-s', mac, '-j', 'DROP']);
      await Process.run('iptables', ['-D', 'FORWARD', '-s', ip, '-j', 'DROP']);
      await Process.run('arping', ['-c', '3', '-I', iface, ip]);
      return {'status': 'unblocked', 'ip': ip, 'mac': mac};
    } catch (e) {
      return {'error': e.toString()};
    }
  }

  @override
Future<Map<String, dynamic>> runSpeedTest() async {
  try {
    final res = await Process.run('speedtest-cli', ['--json']);

    if (res.exitCode != 0) {
      return {'error': res.stderr.toString()};
    }

    final result = json.decode(res.stdout);

  return {
  'download': (((result['download'] as num?) ?? 0).toDouble() / 1e6).toStringAsFixed(2),
  'upload': (((result['upload'] as num?) ?? 0).toDouble() / 1e6).toStringAsFixed(2),
};
  } catch (e) {
    return {'error': e.toString()}; // Catch any exceptions during process execution
  }
}

  @override
  Future<Map<String, double>> getBandwidth() async {
    String interface= await getDefaultInterface()??'';
    final content = await File('/proc/net/dev').readAsLines();
    for (var line in content) {
      line = line.trim();
      if (line.startsWith('$interface:')) {
        final p = line.split(RegExp(r'\s+'));
        final rx = double.tryParse(p[1]) ?? 0;
        final tx = double.tryParse(p[9]) ?? 0;
        return {'download': rx, 'upload': tx};
      }
    }
    return {'download': 0, 'upload': 0};
  }

  @override
  Future<Map<String, double>> getBandwidthDelta( ) async {
       

    final before = await getBandwidth( );
    await Future.delayed(const Duration(seconds: 1));
    final after = await getBandwidth( );
    return {
      'download': (after['download']! - before['download']!),
      'upload': (after['upload']! - before['upload']!),
    };
  }

  @override
  Future<void> setupExitHandler() async {
    final iface = await getDefaultInterface();
    if (iface == null) {
      print("Interface not found for cleanup.");
      exit(1);
    }
    print("Cleaning up...");
    final devices = await scanNetwork();
    for (var d in devices) {
      if (d['blocked'] == true) {
        print('Unblocking ${d['ip']}...');
        await unblockDevice(d['ip']);
      }
    }
    await Process.run('pkill', ['-f', 'arpspoof']);
    print("All cleaned up. Exiting...");
    exit(0);
  }
}
