
/// Defines the interface for network‐scanning and blocking across platforms.
abstract class NetworkManager {
  Future<String?> getDefaultInterface();
  Future<String?> getGatewayIP();
  Future<String?> getMyIP(String interface);
  Future<String?> getMyMAC(String interface);
  Future<String> getHostname(String ip);
  Future<String?> getMAC(String ip);
  Future<bool> isDeviceBlocked(String ip, String? mac);
  Future<Map<String, dynamic>> runSpeedTest();
  Future<Map<String, double>> getBandwidth( );
  Future<Map<String, double>> getBandwidthDelta( );
  Future<List<Map<String, dynamic>>> scanNetwork();
  Future<Map<String, dynamic>> blockDevice(String ip);
  Future<Map<String, dynamic>> unblockDevice(String ip);
  Future<void> setupExitHandler();
}
