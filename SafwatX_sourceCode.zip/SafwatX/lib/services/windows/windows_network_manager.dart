import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';
import 'package:safwatx/models/device_model.dart';
import '../services.dart';

class WindowsNetworkManager implements NetworkManager {
  static const _arpCliAsset = 'assets/WinArpSpoof.exe';
  Process? _spoofProcess;
  final Map<String, String> _deviceStatus = {};

  String? _cachedInterface;
  String? _cachedGateway;
  String? _cachedIp;
  String? _cachedArpCliPath;
// Constructor to start CLI tool on initialization
  WindowsNetworkManager() {
    _startCliTool();
  }

  // Method to start WinArpSpoof.exe with 'start' command
  Future<void> _startCliTool() async {
    try {
      if (_spoofProcess != null) {
        debugPrint('CLI tool is already running');
        return;
      }
      final executable = await _getArpCliExecutable();
      _spoofProcess = await Process.start(executable, ['start']);
      _logProcessOutput(_spoofProcess!);
      debugPrint('WinArpSpoof.exe started successfully');
    } catch (e) {
      debugPrint('Error starting WinArpSpoof.exe: $e');
    }
  }

  @override
  Future<String?> getDefaultInterface() async {
    if (_cachedInterface != null) return _cachedInterface;

    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['interfaces']);
      if (result.exitCode == 0) {
        final regex = RegExp(r"(\d+\.\s+.+?)\s+\(.+?\)");
        _cachedInterface = regex.firstMatch(result.stdout as String)?.group(1);
        print('DEBUG: Default interface: $_cachedInterface');
        return _cachedInterface;
      }
    } catch (e) {
      debugPrint('Error getting default interface: $e');
    }
    return 'unknown';
  }

  @override
  Future<String?> getGatewayIP() async {
    if (_cachedGateway != null) return _cachedGateway;

    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['scan']);
      if (result.exitCode == 0) {
        final regex = RegExp(r"Gateway IP:\s+(\d+\.\d+\.\d+\.\d+)");
        _cachedGateway = regex.firstMatch(result.stdout as String)?.group(1);
        return _cachedGateway;
      }
    } catch (e) {
      debugPrint('Error getting gateway IP: $e');
    }
    return null;
  }

  @override
  Future<String?> getMyIP(String b) async {
    if (_cachedIp != null) return _cachedIp;

    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['scan']);
      if (result.exitCode == 0) {
        final regex = RegExp(r"Local IP:\s+(\d+\.\d+\.\d+\.\d+)");
        _cachedIp = regex.firstMatch(result.stdout as String)?.group(1);
        return _cachedIp;
      }
    } catch (e) {
      debugPrint('Error getting local IP: $e');
    }
    return null;
  }

  @override
  Future<String?> getMAC(String ip) async {
    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['scan']);
      if (result.exitCode == 0) {
        final regex = RegExp("${ip.replaceAll('.', '\\.')}\\s+([\\w:]{17})");
        return regex
            .firstMatch(result.stdout as String)
            ?.group(1)
            ?.toLowerCase();
      }
    } catch (e) {
      debugPrint('Error getting MAC from IP $ip: $e');
    }
    return null;
  }

  @override
  Future<List<Map<String, dynamic>>> scanNetwork() async {
    final devices = <DeviceElement>[];
    String? myIp;
    String? myMac;
    String? myHostname;

    try {
      // Get local device details
      final executable = await _getArpCliExecutable();
      myIp = await getMyIP('');
      myMac = await getMyMAC('');
      myHostname = await resolveHostname(myIp ?? '');
      debugPrint('Local Device: IP=$myIp, MAC=$myMac, Hostname=$myHostname');

      // Run scan
      final result = await Process.run(executable, ['scan']);
      if (result.exitCode == 0) {
        final output = result.stdout.toString();
        debugPrint('Raw CLI Output:\n$output'); // Log raw output

        // Updated regex to handle hostnames with spaces and optional Status column
        final regex = RegExp(
            r'^(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-fA-F:]{17})\s+(.+?)\s+(.+)$',
            multiLine: true);

        // Parse devices, excluding local device
        for (final match in regex.allMatches(output)) {
          final ip = match.group(1)!;
          final mac = match.group(2)!.toLowerCase();
          if (ip == myIp && mac == myMac) continue; // Skip local device
          final hostname = match.group(3)?.trim() ?? ip;
          final vendor = match.group(4)?.trim() ?? 'Unknown Vendor';
          print(match.group(4)?.trim() ?? 'asd');
          debugPrint(
              'Parsed Device: IP=$ip, MAC=$mac, Hostname=$hostname, Vendor=$vendor');

          if (_isValidDevice(ip, mac)) {
            final isBlocked = await isDeviceBlocked(ip, mac);
            devices.add(DeviceElement(
                name: hostname == ip ? await resolveHostname(ip) : hostname,
                ip: ip,
                mac: mac,
                blocked: isBlocked,
                loading: false,
                vendor: vendor));
          }
        }

        // Add local device as the last entry
        if (myIp != null && myMac != null) {
          final isBlocked = await isDeviceBlocked(myIp, myMac);
          devices.add(DeviceElement(
              name: myHostname == myIp
                  ? '$myHostname (your Device)'
                  : '$myHostname (your Device)',
              ip: myIp,
              mac: myMac.toLowerCase(),
              blocked: isBlocked,
              loading: false,
              vendor: 'Local Device'));
        }
      } else {
        debugPrint('CLI scan failed: ${result.stderr}');
      }
    } catch (e) {
      debugPrint('Error scanning network: $e');
    }

    debugPrint('Final Device List: ${devices.map((d) => d.toMap()).toList()}');
    return devices.map((device) => device.toMap()).toList();
  }

  @override
  Future<Map<String, dynamic>> blockDevice(String ip) async {
    try {
      final executable = await _getArpCliExecutable();
      await Process.run(executable, ['block', ip]);

      _deviceStatus[ip] = 'blocked';

      if (_spoofProcess == null) {
        _spoofProcess = await Process.start(executable, ['start']);
        _logProcessOutput(_spoofProcess!);
      }

      return {'status': 'blocking', 'ip': ip};
    } catch (e) {
      debugPrint('Error blocking device $ip: $e');
      return {'status': 'error', 'ip': ip, 'result': e.toString()};
    }
  }

  @override
  Future<Map<String, dynamic>> unblockDevice(String ip) async {
    try {
      final executable = await _getArpCliExecutable();
      await Process.run(executable, ['unblock', ip]);

      _deviceStatus.remove(ip);

      return {'status': 'unblocking', 'ip': ip};
    } catch (e) {
      debugPrint('Error unblocking device $ip: $e');
      return {'status': 'error', 'ip': ip, 'result': e.toString()};
    }
  }

  @override
  Future<bool> isDeviceBlocked(String ip, String? mac) async {
    if (_deviceStatus.containsKey(ip)) {
      return _deviceStatus[ip] == 'blocked';
    }

    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['list']);
      if (result.exitCode == 0) {
        final isBlocked = (result.stdout as String).contains(ip);
        _deviceStatus[ip] = isBlocked ? 'blocked' : 'unblocked';
        return isBlocked;
      }
    } catch (e) {
      debugPrint('Error checking if device is blocked: $e');
    }
    return false;
  }

 

  // Method to list all blocked IPs
  Future<List<String>> listBlockedIPs() async {
    final blockedIPs = <String>[];
    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['list']);
      if (result.exitCode == 0) {
        final output = result.stdout.toString();
        debugPrint('Blocked IPs Output:\n$output');

        // Split output into lines and process each line
        final lines = output.split('\n').map((line) => line.trim()).toList();
        bool isHeader = true; // To skip "Blocked IPs:" header
        for (final line in lines) {
          if (isHeader) {
            if (line == 'Blocked IPs:') {
              isHeader = false;
            }
            continue;
          }
          // Match valid IPv4 address
          final ipRegex = RegExp(r'^\d{1,3}(?:\.\d{1,3}){3}$');
          if (ipRegex.hasMatch(line) && line.isNotEmpty) {
            blockedIPs.add(line);
            _deviceStatus[line] = 'blocked'; // Update status cache
          }
        }
      } else {
        debugPrint('Error listing blocked IPs: ${result.stderr}');
      }
    } catch (e) {
      debugPrint('Error listing blocked IPs: $e');
    }
    debugPrint('Blocked IPs: $blockedIPs');
    return blockedIPs;
  }

  @override
  Future<void> setupExitHandler()async {
    try {
      await listBlockedIPs();
      // Unblock all blocked devices
      final blockedDevices = _deviceStatus.entries
          .where((entry) => entry.value == 'blocked')
          .map((entry) => entry.key)
          .toList();
      for (final ip in blockedDevices) {
        await unblockDevice(ip);
        debugPrint('Unblocked device $ip during cleanup');
      }

      // Stop the CLI tool and kill the process
      if (_spoofProcess != null) {
        final executable = await _getArpCliExecutable();
        await Process.run(executable, ['stop']);
        _spoofProcess?.kill();
        _spoofProcess = null;
      }
    } catch (e) {
      debugPrint('Error during cleanup: $e');
    }finally{exit(0);}
  }


 

Future<String> _getArpCliExecutable() async {
    if (_cachedArpCliPath != null) return _cachedArpCliPath!;

    final tempDir = await getTemporaryDirectory();
    // Use Platform.pathSeparator for Windows compatibility
    final exePath = '${tempDir.path}${Platform.pathSeparator}WinArpSpoof.exe';
    final exeFile = File(exePath);

    if (!await exeFile.exists()) {
      final byteData = await rootBundle.load(_arpCliAsset);
      await exeFile.writeAsBytes(byteData.buffer.asUint8List());
      // Ensure executable permissions (though not needed on Windows, included for completeness)
      if (!Platform.isWindows) {
        await Process.run('chmod', ['+x', exePath]);
      }
    }

    _cachedArpCliPath = exePath;
    debugPrint('CLI Executable Path: $exePath');
    return exePath;
  }
  
  
  
  Future<String> resolveHostname(String ip) async {
    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['scan']);
      if (result.exitCode == 0) {
        final regex = RegExp(
          '${ip.replaceAll('.', '\\.')}\\s+[\\w:]{17}\\s+([^\\s]+)',
          caseSensitive: false,
        );
        final match = regex.firstMatch(result.stdout as String);
        if (match != null && match.group(1) != ip) {
          return match.group(1)!;
        }
      }

      final nsResult = await Process.run('nslookup', [ip]);
      final nsMatch = RegExp(r'Name:\s+(.+)', caseSensitive: false)
          .firstMatch(nsResult.stdout.toString());
      return nsMatch?.group(1)?.trim() ?? ip;
    } catch (e) {
      debugPrint('Error resolving hostname for $ip: $e');
      return ip;
    }
  }

  bool _isValidDevice(String ip, String mac) {
    return ip != '0.0.0.0' &&
        !mac.startsWith('00:00:00') &&
        !mac.startsWith('ff:ff:ff') &&
        !ip.startsWith('224.') &&
        !ip.startsWith('239.') &&
        ip != '255.255.255.255' &&
        !mac.contains('00-00-00') &&
        !mac.startsWith('33:33') &&
        !mac.endsWith('ff:ff') &&
        !mac.contains('ff-ff');
  }

  void _logProcessOutput(Process process) {
    process.stdout
        .transform(SystemEncoding().decoder)
        .listen((data) => debugPrint('WinArpSpoof stdout: $data'));
    process.stderr
        .transform(SystemEncoding().decoder)
        .listen((data) => debugPrint('WinArpSpoof stderr: $data'));
    process.exitCode
        .then((code) => debugPrint('WinArpSpoof exited with code $code'));
  }

  @override
  Future<String?> getMyMAC(String interface) async {
    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['scan']);
      if (result.exitCode == 0) {
        final regex = RegExp(r"Local MAC:\s+([\w:]{17})");
        return regex
            .firstMatch(result.stdout as String)
            ?.group(1)
            ?.toLowerCase();
      }
    } catch (e) {
      debugPrint('Error getting local MAC: $e');
    }
    return null;
  }

  @override
  Future<String> getHostname(String ip) async => resolveHostname(ip);

  @override
  Future<Map<String, double>> getBandwidth([String? interface]) async {
    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['bandwidth']);
      if (result.exitCode == 0) {
        final output = result.stdout.toString();
        final downloadRegex = RegExp(r'Download:\s*(\d+\.?\d*)\s*bytes');
        final uploadRegex = RegExp(r'Upload:\s*(\d+\.?\d*)\s*bytes');

        final downloadMatch = downloadRegex.firstMatch(output);
        final uploadMatch = uploadRegex.firstMatch(output);

        if (downloadMatch != null && uploadMatch != null) {
          return {
            'download': double.parse(downloadMatch.group(1)!),
            'upload': double.parse(uploadMatch.group(1)!)
          };
        }
      }
      debugPrint('Error parsing bandwidth output: ${result.stdout}');
    } catch (e) {
      debugPrint('Error getting bandwidth: $e');
    }
    return {'download': 0.0, 'upload': 0.0};
  }

  @override
  Future<Map<String, double>> getBandwidthDelta() async {
    try {
      final start = DateTime.now();
      // Get bandwidth statistics using wmic
      final sample = await Process.run('wmic', [
        'path',
        'Win32_PerfFormattedData_Tcpip_NetworkInterface',
        'get',
        'BytesReceivedPersec,BytesSentPersec'
      ]);
      if (sample.exitCode != 0) {
        debugPrint('Error getting bandwidth sample: ${sample.stderr}');
        return {'download': 0.0, 'upload': 0.0};
      }

      final lines = sample.stdout.toString().split('\n');
      double download = 0.0;
      double upload = 0.0;
      for (var line in lines) {
        if (line.contains('BytesReceivedPersec')) continue; // Skip header
        final parts = line.trim().split(RegExp(r'\s+'));
        if (parts.length >= 2) {
          download = double.tryParse(parts[0]) ?? 0.0;
          upload = double.tryParse(parts[1]) ?? 0.0;
          break;
        }
      }
      print('DEBUG: Sample - Received: $download, Sent: $upload');

      final duration = DateTime.now().difference(start).inMilliseconds;
      print('DEBUG: getBandwidthDelta took $duration ms');
      print('DEBUG: Parsed download: $download, upload: $upload');

      return {'download': download, 'upload': upload};
    } catch (e) {
      debugPrint('Error getting bandwidth delta: $e');
    }
    return {'download': 0.0, 'upload': 0.0};
  }

  @override
  Future<Map<String, dynamic>> runSpeedTest() async {
    try {
      final executable = await _getArpCliExecutable();
      final result = await Process.run(executable, ['speedtest']);
      if (result.exitCode == 0) {
        final output = result.stdout.toString();
        final downloadBytesRegex = RegExp(r'Downloaded:\s*(\d+)\s*bytes');
        final timeRegex = RegExp(r'Time:\s*(\d+\.\d+)\s*ms');
        final speedRegex = RegExp(r'Download Speed:\s*(\d+\.\d+)\s*Mbps');

        final downloadBytesMatch = downloadBytesRegex.firstMatch(output);
        final timeMatch = timeRegex.firstMatch(output);
        final speedMatch = speedRegex.firstMatch(output);

        if (downloadBytesMatch != null &&
            timeMatch != null &&
            speedMatch != null) {
          return {
            'download_bytes': int.parse(downloadBytesMatch.group(1)!),
            'time_ms': double.parse(timeMatch.group(1)!),
            'download': double.parse(speedMatch.group(1)!),
            'upload': 'Not implemented',
          };
        }
        return {'error': 'Failed to parse speed test output: $output'};
      } else {
        return {'error': 'Speed test failed: ${result.stderr}'};
      }
    } catch (e) {
      debugPrint('Error running speed test: $e');
      return {'error': e.toString()};
    }
  }
}
