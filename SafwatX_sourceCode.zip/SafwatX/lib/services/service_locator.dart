import 'package:get_it/get_it.dart';
import 'package:safwatx/providers/network_manger_provider.dart';
import 'package:safwatx/providers/network_provider.dart';
import 'package:safwatx/services/services.dart';

final getIt = GetIt.instance;

void setupServiceLocator() {
  // Register NetworkManager as a singleton
  getIt.registerSingleton<NetworkManager>(NetworkManagerProvider.getNetworkManager());
  
  // Register NetworkProvider
  getIt.registerFactory(() => NetworkProvider(networkManager: getIt<NetworkManager>()));
}