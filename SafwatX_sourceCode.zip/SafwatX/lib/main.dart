import 'dart:io';

import 'package:flex_color_scheme/flex_color_scheme.dart';
import 'package:flutter/material.dart';
import 'package:safwatx/providers/SettingsProvider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:safwatx/screens/Dashboard/home_screen.dart';
import 'package:safwatx/services/service_locator.dart';

import 'package:toastification/toastification.dart';
import 'package:window_manager/window_manager.dart';
import 'providers/network_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize dependency injection
  setupServiceLocator();

  // Initialize window manager
  await windowManager.ensureInitialized();

  runApp(SafwatXApp());
}


class SafwatXApp extends StatefulWidget {
  const SafwatXApp({super.key});

  @override
  State<SafwatXApp> createState() => _SafwatXAppState();
}

class _SafwatXAppState extends State<SafwatXApp> with WindowListener {
  late NetworkProvider _networkProvider;
  @override
  void initState() {
    super.initState();
    windowManager.addListener(this);
    _init();

    // Initialize network provider after services are ready
    _networkProvider = getIt<NetworkProvider>();

    // Delay the scan until after the widget has built
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.microtask(() {
        if (navigatorKey.currentContext != null) {
          _networkProvider.scanNetwork(navigatorKey.currentContext!);
        }
      });
    });
  }
  @override
  void dispose() {
    windowManager.removeListener(this);
    super.dispose();
  }

  void _init() async {
    await windowManager.setPreventClose(true);
    setState(() {});
  }

  @override
  void onWindowClose() async {
    bool _isPreventClose = await windowManager.isPreventClose();
    if (_isPreventClose) {
      final shouldExit = await showDialog<bool>(
        context: navigatorKey.currentContext!,
        builder: (ctx) => AlertDialog(
          title: const Text(
              'the app is about to close do you want to ternimate all old blocks'),
          actions: [
            TextButton(
              child: const Text('cancel'),
              onPressed: () => Navigator.of(ctx).pop(false),
            ),
             TextButton(
                child: navigatorKey.currentContext!
                    .read<NetworkProvider>()
                    .isCleanExitLoading
                    ? const CircularProgressIndicator()
                    : const Text('close & clean'),
                onPressed: () async {
                  showDialog(
                    context: navigatorKey.currentContext!,
                    barrierDismissible: false,
                    builder: (_) => const Center(
                      child: CircularProgressIndicator(),
                    ),
                  );
                  await navigatorKey.currentContext!
                      .read<NetworkProvider>()
                      .cleanExitApp();
            
                }),
            TextButton(
              child: const Text('close without clean'),
              onPressed: () => exit(0),
            ),
          ],
        ),
      );

      if (shouldExit == true) {
        await windowManager.destroy();
      }
    }
  }

  final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: _networkProvider),
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
      ],
      child: ToastificationWrapper(
        child: Consumer<SettingsProvider>(
          builder: (context, settingsProvider, _) {
            return MaterialApp(
              localizationsDelegates: [
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
              ],
              supportedLocales: const [
                Locale('en', 'US'),
                Locale('ar', 'EG'),
              ],
              navigatorKey: navigatorKey,
              title: 'SafwatX Network Manager',
              theme: FlexThemeData.light(scheme: FlexScheme.bahamaBlue),
              darkTheme: FlexThemeData.dark(scheme: FlexScheme.bahamaBlue),
              themeMode: settingsProvider.themeMode,
              debugShowCheckedModeBanner: false,
              home: const NetworkDashboardPage(),
            );
          },
        ),
      ),
    );
  }
}
