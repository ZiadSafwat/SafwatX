import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sidebarx/sidebarx.dart';

class SettingsProvider with ChangeNotifier {
  static const _themeModeKey = 'theme_mode';

  ThemeMode _themeMode = ThemeMode.dark;
  SidebarXController _controller = SidebarXController(selectedIndex: 0, extended: true);

  SidebarXController get controller => _controller;

  // void setSelectedIndex(int index) {
  //   _controller.selectedIndex = index;
  //   notifyListeners();
  // }
  //
  // void setExtended(bool extended) {
  //   _controller.extended = extended;
  //
  SettingsProvider() {
    _loadSettings();
  }

  ThemeMode get themeMode => _themeMode;

  void toggleTheme(bool isDark) {
    _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    _saveThemeMode();
    notifyListeners();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final theme = prefs.getString(_themeModeKey) ?? 'dark';
    _themeMode = theme == 'dark' ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
  }

  Future<void> _saveThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themeModeKey, _themeMode == ThemeMode.dark ? 'dark' : 'light');
  }
}
