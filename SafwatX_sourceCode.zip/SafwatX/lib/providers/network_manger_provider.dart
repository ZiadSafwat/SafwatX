import 'dart:io';
import 'package:safwatx/services/services.dart';
import '../services/linux/linux_network_manager.dart';
import '../services/windows/windows_network_manager.dart';


class NetworkManagerProvider {
  static NetworkManager getNetworkManager() {
    if (Platform.isLinux) {
      return LinuxNetworkManager();
    } else if (Platform.isWindows) {
      return WindowsNetworkManager();
    } else {
      throw UnsupportedError('Platform not supported');
    }
  }
}