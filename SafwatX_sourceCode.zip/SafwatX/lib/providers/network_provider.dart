import 'dart:async';
import 'dart:io';
import 'package:excel/excel.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:safwatx/models/device_model.dart';
import 'package:safwatx/services/services.dart';
import 'package:toastification/toastification.dart';
import '../screens/Dashboard/table.dart';

class NetworkProvider with ChangeNotifier {
  final NetworkManager _networkManager;
  List<DeviceElement> devices = [];
  bool isSearchLoading = false;
  bool isCleanExitLoading = false;
  int sortColumnIndex;
  bool sortAscending;
  bool isSpeedTest = false;
  TableData? data;
  bool _isArpSpoofingActive = false;
  bool _isUpdatingBandwidth = false;
     
  bool get isArpSpoofingActive => _isArpSpoofingActive;
  String downloadSpeed = '0', uploadSpeed = '0',downloadUnit='';
  String lastDownloadMbps = '0', lastUploadMbps = '0',uploadUnit='';
  Map<String, TimeOfDay> blockSchedules = {};
  Timer? _bandwidthTimer;
  Timer? _scheduleTimer;

NetworkProvider({
    required NetworkManager networkManager,
    this.sortColumnIndex = 0,
    this.sortAscending = true,
  }) : _networkManager = networkManager {
    _bandwidthTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      if (!_isUpdatingBandwidth) {
        await updateBandwidth();
      } else {
        print('DEBUG: Skipped bandwidth update due to ongoing operation');
      }
    });
    _scheduleTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      _checkSchedules();
    });
  }

  @override
  void dispose() {
    _bandwidthTimer?.cancel();
    _scheduleTimer?.cancel();
    super.dispose();
  }

 Future<void> updateBandwidth() async {
    if (_isUpdatingBandwidth) return;
    _isUpdatingBandwidth = true;
    try {
      final start = DateTime.now();
      final delta = await _networkManager.getBandwidthDelta();
      final duration = DateTime.now().difference(start).inMilliseconds;
      debugPrint('DEBUG: updateBandwidth took $duration ms');
      debugPrint('DEBUG: getBandwidthDelta result: $delta');

      // Convert bytes to appropriate units (KB, MB) and format
      final download = delta['download'] as num? ?? 0;
      final upload = delta['upload'] as num? ?? 0;

 
      double downloadValue;
      double uploadValue;

      if (download > 1024 * 1024) {
        downloadValue = (download / (1024 * 1024)).toDouble();
        downloadUnit = 'MB/s';
      } else if (download > 1024) {
        downloadValue = (download / 1024).toDouble();
        downloadUnit = 'KB/s';
      } else {
        downloadValue = download.toDouble();
        downloadUnit = 'bytes/s';
      }

      if (upload > 1024 * 1024) {
        uploadValue = (upload / (1024 * 1024)).toDouble();
        uploadUnit = 'MB/s';
      } else if (upload > 1024) {
        uploadValue = (upload / 1024).toDouble();
        uploadUnit = 'KB/s';
      } else {
        uploadValue = upload.toDouble();
        uploadUnit = 'bytes/s';
      }

      downloadSpeed = downloadValue.toStringAsFixed(2) ;
      uploadSpeed = uploadValue.toStringAsFixed(2) ;

      debugPrint('Bandwidth: download=$downloadSpeed $downloadUnit, upload=$uploadSpeed $uploadUnit');
      notifyListeners();
    } catch (e) {
      debugPrint('Error updating bandwidth: $e');
      downloadSpeed = '0';
      uploadSpeed = '0';
      notifyListeners();
    } finally {
      _isUpdatingBandwidth = false;
    }
  }
  void showNotification(String title, String body) {
    toastification.show(
      type: ToastificationType.info,
      style: ToastificationStyle.minimal,
      title: Text(title),
      description: Text(body),
      alignment: Alignment.topLeft,
      autoCloseDuration: const Duration(seconds: 6),
      animationBuilder: (context, animation, alignment, child) =>
          FadeTransition(opacity: animation, child: child),
      primaryColor: const Color(0xff3281bc),
      icon: const Icon(Icons.notifications),
      borderRadius: BorderRadius.circular(12.0),
      dragToClose: true,
      pauseOnHover: false,
      applyBlurEffect: true,
    );
  }

  Future<void> scanNetwork(BuildContext context) async {
    devices = [];
    isSearchLoading = true;
    notifyListeners();
    initializeData(context);

    try {
      final response = await _networkManager.scanNetwork();
      devices = response.map((m) => DeviceElement.fromMap(m)).toList();
      data!.setData(devices);
    } catch (e) {
      if (kDebugMode) print("❌ Exception: $e");
      showNotification('❌ Error scanning network:', "$e");
    } finally {
      isSearchLoading = false;
      notifyListeners();
    }
  }

  void exportToExcel() async {
    final List<List<dynamic>> excelData = [
      ['Name', 'Ip', 'Mac', 'Blocked']
    ];
    for (final d in devices) {
      excelData.add([d.name, d.ip, d.mac, d.blocked]);
    }

    final excel = Excel.createExcel();
    final sheet = excel['Sheet1'];
    for (var i = 0; i < excelData.length; i++) {
      for (var j = 0; j < excelData[i].length; j++) {
        final val = excelData[i][j];
        final cell =
            sheet.cell(CellIndex.indexByColumnRow(columnIndex: j, rowIndex: i));
        if (val is bool) {
          cell.value = BoolCellValue(val);
        } else if (val is int) {
          cell.value = IntCellValue(val);
        } else if (val is double) {
          cell.value = DoubleCellValue(val);
        } else {
          cell.value = TextCellValue(val.toString());
        }
      }
    }

    const fileName = 'table_data.xlsx';
    final bytes = excel.save();
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$fileName')..writeAsBytesSync(bytes!);
    await OpenFilex.open(file.path);
    showNotification('Export Successful', 'Saved as $fileName');
  }

  void filterData(String query) {
    data!.resetData();
    data!.search(query);
    notifyListeners();
  }

  void sort<T>(
    Comparable<T> Function(DeviceElement d) getField,
    int columnIndex,
    bool ascending,
  ) {
    data!.sort<T>(getField, ascending);
    sortColumnIndex = columnIndex;
    sortAscending = ascending;
    notifyListeners();
  }

  void initializeData(BuildContext context) {
    data = TableData(context);
    notifyListeners();
  }

  TableData returnData(BuildContext context) {
    data ??= TableData(context);
    return data!;
  }

  Future<void> cleanExitApp() async {
    isCleanExitLoading = true;
    notifyListeners();
    try {
      await _networkManager.setupExitHandler();
    } catch (e) {
      if (kDebugMode) print("❌ Exception: $e");
      showNotification('❌ Error exiting:', "$e");
    } finally {
      isCleanExitLoading = false;
      notifyListeners();
    }
  }

  Future<void> changeBlockState(bool isLocked, String ip, int index, {TimeOfDay? schedule}) async {
    data!.changeLoadingState(index, true);
    notifyListeners();

    try {
      final resp = isLocked
          ? await _networkManager.unblockDevice(ip)
          : await _networkManager.blockDevice(ip);
      if (!resp.containsKey('error')) {
        data!.changeBlockState(index, !isLocked);
        if (schedule != null && !isLocked) {
          scheduleBlock(ip, schedule);
        }
        showNotification('Done', 'Block state for $ip → ${!isLocked}');
      } else {
        showNotification('❌ Error:', resp['error'].toString());
      }
    } catch (e) {
      showNotification('❌ Exception:', e.toString());
    } finally {
      data!.changeLoadingState(index, false);
      notifyListeners();
    }
  }

  Future<void> autoRepair(BuildContext ctx) async {
    try {
      devices = [];
      isSearchLoading = true;
      notifyListeners();
      for (var d in devices.where((d) => d.blocked)) {
        await _networkManager.unblockDevice(d.ip);
      }

      await Process.run('systemctl', ['restart', 'NetworkManager']);
      scanNetwork(ctx);
      showNotification('Repair', 'Services restarted & devices unblocked');
    } catch (e) {
      showNotification('Repair Error', e.toString());
    } finally {
      isSearchLoading = false;
      notifyListeners();
    }
  }

  Future<void> performSpeedTest() async {
    isSpeedTest = true;
    notifyListeners();
    final res = await _networkManager.runSpeedTest();
    lastDownloadMbps = res['download'].toString();
    lastUploadMbps = res['upload'].toString();
    isSpeedTest = false;
    notifyListeners();
  }

  void scheduleBlock(String ip, TimeOfDay time) {
    blockSchedules[ip] = time;
    notifyListeners();
  }

  Future<void> _checkSchedules() async {
    final now = TimeOfDay.now();
    for (final kv in blockSchedules.entries) {
      if (kv.value.hour == now.hour && kv.value.minute == now.minute) {
        await _networkManager.blockDevice(kv.key);
        final formatted =
            '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
        showNotification(
            'Scheduled Block Triggered', '${kv.key} at $formatted');
      }
    }
  }
}