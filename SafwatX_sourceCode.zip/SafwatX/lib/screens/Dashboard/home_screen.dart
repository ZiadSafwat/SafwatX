import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/SettingsProvider.dart';
import '../../providers/network_provider.dart';
import 'table.dart';

class NetworkDashboardPage extends StatelessWidget {
   const NetworkDashboardPage({super.key});
    @override
  Widget build(BuildContext context) {

     final provider = context.watch<NetworkProvider>();
    final maxItemWidth = 280.0;

    Widget buildInfoCards() {
      final cards = <Widget>[];

      if (provider.devices.isNotEmpty) {
        final d = provider.devices.last;
        cards.addAll([
          _infoCard(context, Icons.router, 'Device Name', d.name, maxItemWidth),
          _infoCard(context, Icons.lan, 'IP Address', d.ip, maxItemWidth),
          _infoCard(context, Icons.memory, 'MAC Address', d.mac, maxItemWidth),
        ]);
      } else {
        cards.add(
            _infoCard(context, Icons.error, 'No Devices', '—', maxItemWidth));
      }

      cards.addAll([
        _infoCard(context, Icons.download, 'Download '+provider.downloadUnit,
            provider.downloadSpeed  , maxItemWidth),
        _infoCard(context, Icons.upload, 'Upload '+provider.uploadUnit,
            provider.uploadSpeed , maxItemWidth),
      ]);

      cards.addAll([
        _infoCard(context, Icons.speed, 'Last DL (Mbps)',
            provider.lastDownloadMbps , maxItemWidth),
        _infoCard(context, Icons.speed, 'Last UL (Mbps)',
            provider.lastUploadMbps , maxItemWidth),
      ]);

      return Wrap(spacing: 16, runSpacing: 16, children: cards);
    }

    return Scaffold(

      body: Row(children: [
        // SidebarX(
        //   controller: context.watch<SettingsProvider>().controller,
        //   extendedTheme: SidebarXTheme(
        //     width: 200,
        //
        //   ),
        //   items: const [
        //     SidebarXItem(icon: Icons.dashboard, label: 'Dashboard'),
        //     SidebarXItem(icon: Icons.devices, label: 'Devices'),
        //     SidebarXItem(icon: Icons.history, label: 'History'),
        //     SidebarXItem(icon: Icons.settings, label: 'Settings'),
        //   ],
        //
        // ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'SafwatX 🚀 - My Network 💻',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      Row(
                        children: [
                          Icon(
                            context.watch<SettingsProvider>().themeMode ==
                                    ThemeMode.light
                                ? Icons.light_mode
                                : Icons.dark_mode,
                          ),
                          Switch(
                            value:
                                context.watch<SettingsProvider>().themeMode ==
                                    ThemeMode.dark,
                            onChanged: (val) {
                              context.read<SettingsProvider>().toggleTheme(val);
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  /// Info Cards
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Wrap(
                      alignment: WrapAlignment.start,
                      spacing: 10,
                      runSpacing: 10,
                      children: [buildInfoCards()],
                    ),
                  ),
                  const SizedBox(height: 16),

                  /// Actions
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Wrap(
                      alignment: WrapAlignment.start,
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        ElevatedButton.icon(
                          icon: const Icon(Icons.refresh),
                          label: const Text('Scan & Refresh'),
                          onPressed: provider.isSearchLoading
                              ? null
                              : () => provider.scanNetwork(context),
                        ),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.insert_drive_file),
                          label: const Text('Export Excel'),
                          onPressed: provider.exportToExcel,
                        ),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.speed),
                          label: provider.isSpeedTest?const Text('Testing Internet Speed ...'):const Text('Speed Test'),
                          onPressed:provider.isSpeedTest
                              ? null: provider.performSpeedTest,
                        ),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.schedule),
                          label: const Text('Schedule Block'),
                          onPressed: () async {
                            final result = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (result != null) {
                              final ip = await _askForInput(context,
                                  'Enter IP to block at ${result.format(context)}');
                              if (ip != null)
                                provider.scheduleBlock(ip, result);
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  /// Device Table
                  Card(
                    shape: Theme.of(context).cardTheme.shape ??
                        RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                    color: Theme.of(context).cardTheme.color,
                    elevation: Theme.of(context).cardTheme.elevation ?? 2,
                    child: Padding(
                      padding: Theme.of(context).cardTheme.margin ??
                          const EdgeInsets.all(8),
                      child: DevicesTabel(context: context),
                    ),
                  ),
                  const SizedBox(height: 16),

                  /// Online Status
              //    const Align(
             //       alignment: Alignment.bottomRight,
              //      child: Row(
              //        mainAxisSize: MainAxisSize.min,
              //        children: [
              //          Icon(Icons.circle, color: Colors.green, size: 12),
            //            SizedBox(width: 5),
             //           Text(
                   //       'Online',
               //         ),
            //          ],
               //     ),
               //   ),
                ],
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Future<String?> _askForInput(BuildContext context, String label) {
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(label),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, null),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, ctrl.text.trim()),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Widget _infoCard(BuildContext context, IconData icon, String title,
      String value, double maxWidth) {
    final theme = Theme.of(context);
    final cardTheme = theme.cardTheme;

    return ConstrainedBox(
      constraints: BoxConstraints(maxWidth: maxWidth),
      child: Card(
        color: cardTheme.color,
        shape: cardTheme.shape ??
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: cardTheme.elevation ?? 2,
        child: Padding(
          padding: cardTheme.margin ?? const EdgeInsets.all(12),
          child: Row(
            children: [
              Icon(icon, color: theme.iconTheme.color),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: theme.textTheme.labelSmall),
                    Text(value,
                        style: theme.textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
