import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/network_provider.dart';
import '../../models/device_model.dart';
import 'widgets/searchField.dart';

class DevicesTabel extends StatefulWidget {
  final BuildContext context;

  const DevicesTabel({Key? key, required this.context}) : super(key: key);

  @override
  _DevicesTabelState createState() => _DevicesTabelState();
}

class _DevicesTabelState extends State<DevicesTabel> {
  TextEditingController search = TextEditingController();
  int rowsPerPage = 3;

  @override
  Widget build(BuildContext context) {
    final provider = context.read<NetworkProvider>();
    double height = MediaQuery.of(context).size.height;
    return !(provider.isSearchLoading || provider.data == null)
        ? SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 0.02 * height),
                CustomSearch(
                  prefix: const Icon(Icons.search),
                  controller: search,
                  hintText: 'search by name',
                  isDigit: false,
                  onChanged: (query) {
                    provider.filterData(query);
                  },
                ),
                SizedBox(
                  height: height * 0.5,
                  child: ListView(
                    padding: const EdgeInsets.only(left: 8.0),
                    children: [
                      PaginatedDataTable(
                        source: provider.data!,
                        columns: [
                          DataColumn(
                            label: const Text('Device Name'),
                            onSort: (int columnIndex, bool ascending) =>
                                provider.sort<String>(
                              (DeviceElement d) => d.name,
                              columnIndex,
                              ascending,
                            ),
                          ),
                          DataColumn(
                            label: const Text('MAC Address'),
                            onSort: (int columnIndex, bool ascending) =>
                                provider.sort<String>(
                              (DeviceElement d) => d.mac,
                              columnIndex,
                              ascending,
                            ),
                          ),
                          DataColumn(
                            label: const Text('IP Address'),
                            onSort: (int columnIndex, bool ascending) =>
                                provider.sort<String>(
                              (DeviceElement d) => d.ip.toString(),
                              columnIndex,
                              ascending,
                            ),
                          ),      DataColumn(
                            label: const Text('Device Vendor'),
                            onSort: (int columnIndex, bool ascending) =>
                                provider.sort<String>(
                              (DeviceElement d) => d.vendor.toString(),
                              columnIndex,
                              ascending,
                            ),
                          ),
                          DataColumn(
                            label: const Text('Access'),
                            onSort: (int columnIndex, bool ascending) =>
                                provider.sort<String>(
                              (DeviceElement d) => d.blocked.toString(),
                              columnIndex,
                              ascending,
                            ),
                          ),
                        ],
                        availableRowsPerPage: const [3, 4, 5, 6, 7, 8, 9],
                        rowsPerPage: rowsPerPage,
                        onRowsPerPageChanged: (value) {
                          setState(() {
                            rowsPerPage = value!;
                          });
                        },
                        columnSpacing: 10,
                        horizontalMargin: 5,
                        sortColumnIndex: provider.sortColumnIndex,
                        sortAscending: provider.sortAscending,
                        showCheckboxColumn: false,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
        : const Center(
            child: CircularProgressIndicator(),
          );
  }
}

// The "source" of the table
class TableData extends DataTableSource {
  List<DeviceElement> _originalData = [];
  List<DeviceElement> _filteredData = [];
  BuildContext context;

  TableData(this.context);

  void setData(List<DeviceElement> device) {
    _originalData = device;
    _filteredData = device;
    notifyListeners();
  }

  void changeLoadingState(int i, bool loadingState) {
    _filteredData[i] = _filteredData[i].copyWith(loading: loadingState);
    notifyListeners();
  }

  void changeBlockState(int i, bool isLocked) {
    _filteredData[i] = _filteredData[i].copyWith(blocked: isLocked);
    notifyListeners();
  }

  void search(String query) {
    final terms = query
        .toLowerCase()
        .trim()
        .split(RegExp(r'\s+'))
        .where((t) => t.isNotEmpty)
        .toList();

    if (terms.isEmpty) {
      _filteredData = List<DeviceElement>.from(_originalData);
    } else {
      _filteredData = _originalData.where((device) {
        final haystack =
            '${device.name} ${device.ip} ${device.mac}'.toLowerCase();
        return terms.every((term) => haystack.contains(term));
      }).toList();
    }

    notifyListeners();
  }

  void resetData() {
    _filteredData = _originalData;
    notifyListeners();
  }

  void sort<T>(
      Comparable<T> Function(DeviceElement d) getField, bool ascending) {
    _filteredData.sort((DeviceElement a, DeviceElement b) {
      if (!ascending) {
        final DeviceElement c = a;
        a = b;
        b = c;
      }
      final Comparable<T> aValue = getField(a);
      final Comparable<T> bValue = getField(b);
      return Comparable.compare(aValue, bValue);
    });
    notifyListeners();
  }

  @override
  bool get isRowCountApproximate => false;

  @override
  int get rowCount => _filteredData.length;

  @override
  int get selectedRowCount => 0;

  @override
  DataRow getRow(int index) {
    final DeviceElement data = _filteredData[index];

    return DataRow(
      cells: [
        DataCell(Text(data.name,overflow: TextOverflow.ellipsis,)),
        DataCell(Text(data.mac,overflow: TextOverflow.ellipsis,)),
        DataCell(Text(data.ip,overflow: TextOverflow.ellipsis,)),
        DataCell(Text(data.vendor,overflow: TextOverflow.ellipsis,)),
        DataCell(
          data.loading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : IconButton(
                  icon: Icon(
                    data.blocked ? Icons.block : Icons.check_circle_outline,
                    color: data.blocked ? Colors.red : Colors.green,
                  ),
                  tooltip: data.blocked
                      ? 'Blacklisted (Click to allow)'
                      : 'Whitelisted (Click to block)',
                  onPressed: () {
                    Provider.of<NetworkProvider>(context, listen: false)
                        .changeBlockState(data.blocked, data.ip, index);
                  },
                ),
        ),
      ],
    );
  }
}
