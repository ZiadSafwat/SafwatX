// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../providers/network_provider.dart';
//
// void showBandwidthDialog(BuildContext context, String ip,) {
//   final TextEditingController rateController = TextEditingController(text: '5');
//   showDialog(
//     context: context,
//     builder: (_) => AlertDialog(
//       title: Text('Set Bandwidth for Device $ip'),
//       content: TextField(
//         controller: rateController,
//         decoration: InputDecoration(hintText: 'Enter rate in kbps'),
//         keyboardType: TextInputType.number,
//       ),
//       actions: [
//         TextButton(
//           child: Text('Cancel'),
//           onPressed: () => Navigator.pop(context),
//         ),
//         TextButton(
//           child: Text('Set'),
//           onPressed: () {
//             if (rateController.text.isNotEmpty) {
//               context.read<NetworkProvider>().limitDeviceBandwidth(
//                   ip, double.parse(rateController.text));
//             }
//             Navigator.pop(context);
//           },
//         ),
//       ],
//     ),
//   );
// }
