        //#include "my_application.h"
        //
        //int main(int argc, char** argv) {
        //  g_autoptr(MyApplication) app = my_application_new();
        //  return g_application_run(G_APPLICATION(app), argc, argv);
        //}
        #include "my_application.h"
        #include <unistd.h>
        #include <stdlib.h>
        #include <sstream>
        #include <iostream>

        int main(int argc, char** argv) {
          if (getuid() != 0) {
            std::cerr << "Not running as root. Attempting to relaunch with pkexec...\n";

            // Rebuild command with GUI env variables
            std::stringstream command;
            command << "pkexec env DISPLAY=$DISPLAY XAUTHORITY=$XAUTHORITY \"" << argv[0] << "\"";
            for (int i = 1; i < argc; ++i) {
              command << " \"" << argv[i] << "\"";
            }

            return system(command.str().c_str());
          }

          g_autoptr(MyApplication) app = my_application_new();
          return g_application_run(G_APPLICATION(app), argc, argv);
        }

